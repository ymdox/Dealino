"use client"

import type React from 'react'
import { createContext, useContext, useState, useEffect } from 'react'

interface User {
  id: string
  email: string
  username: string
  avatar?: string
  joinedDate: string
  dealsPosted: number
  reputation: number
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (email: string, username: string, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Mock users database
const mockUsers: User[] = [
  {
    id: '1',
    email: 'john@example.com',
    username: 'TechDealer',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
    joinedDate: '2023-01-15',
    dealsPosted: 47,
    reputation: 892
  },
  {
    id: '2',
    email: 'marie@example.com',
    username: 'BargainHunter',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b5b0?w=100&h=100&fit=crop&crop=face',
    joinedDate: '2023-03-22',
    dealsPosted: 23,
    reputation: 456
  }
]

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('dealabs_user')
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))

    const foundUser = mockUsers.find(u => u.email === email)
    if (foundUser && password === 'password123') {
      setUser(foundUser)
      localStorage.setItem('dealabs_user', JSON.stringify(foundUser))
      setIsLoading(false)
      return true
    }

    setIsLoading(false)
    return false
  }

  const register = async (email: string, username: string, password: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))

    // Check if user already exists
    const existingUser = mockUsers.find(u => u.email === email || u.username === username)
    if (existingUser) {
      setIsLoading(false)
      return false
    }

    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      username,
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face",
      joinedDate: new Date().toISOString().split('T')[0],
      dealsPosted: 0,
      reputation: 10
    }

    mockUsers.push(newUser)
    setUser(newUser)
    localStorage.setItem('dealabs_user', JSON.stringify(newUser))
    setIsLoading(false)
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('dealabs_user')
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
