"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useAuth } from "@/contexts/AuthContext"
import { Calendar, Euro, ExternalLink, ImageIcon, Loader2, Tag } from "lucide-react"

interface DealSubmissionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onDealSubmitted?: (deal: any) => void
}

export function DealSubmissionDialog({ open, onOpenChange, onDealSubmitted }: DealSubmissionDialogProps) {
  const { user } = useAuth()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [dealForm, setDealForm] = useState({
    title: "",
    description: "",
    price: "",
    originalPrice: "",
    dealUrl: "",
    imageUrl: "",
    store: "",
    category: "",
    expiryDate: ""
  })

  const categories = [
    "Informatique",
    "Smartphones",
    "Gaming",
    "Audio",
    "TV & Audio",
    "Mode",
    "Maison",
    "Auto",
    "Voyage",
    "Sport",
    "Livres",
    "Alimentation"
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsSubmitting(true)

    // Simulate API submission
    await new Promise(resolve => setTimeout(resolve, 2000))

    const discount = dealForm.originalPrice && dealForm.price
      ? Math.round(((Number.parseFloat(dealForm.originalPrice) - Number.parseFloat(dealForm.price)) / Number.parseFloat(dealForm.originalPrice)) * 100)
      : 0

    const newDeal = {
      id: Math.random().toString(36).substr(2, 9),
      title: dealForm.title,
      description: dealForm.description,
      price: `${dealForm.price} €`,
      originalPrice: dealForm.originalPrice ? `${dealForm.originalPrice} €` : undefined,
      discount: discount > 0 ? `-${discount}%` : undefined,
      temperature: 10, // New deals start with base temperature
      comments: 0,
      image: dealForm.imageUrl || "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=300&h=300&fit=crop",
      store: dealForm.store,
      author: user.username,
      timeAgo: "maintenant",
      isHot: false,
      category: dealForm.category,
      dealUrl: dealForm.dealUrl,
      expiryDate: dealForm.expiryDate,
      authorAvatar: user.avatar
    }

    onDealSubmitted?.(newDeal)
    onOpenChange(false)
    setIsSubmitting(false)

    // Reset form
    setDealForm({
      title: "",
      description: "",
      price: "",
      originalPrice: "",
      dealUrl: "",
      imageUrl: "",
      store: "",
      category: "",
      expiryDate: ""
    })
  }

  if (!user) {
    return null
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Partager un nouveau deal</DialogTitle>
          <DialogDescription>
            Faites profiter la communauté d'une bonne affaire que vous avez trouvée
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="title">Titre du deal *</Label>
              <Input
                id="title"
                placeholder="ex: iPhone 15 Pro 256GB - Prix exceptionnel"
                value={dealForm.title}
                onChange={(e) => setDealForm({ ...dealForm, title: e.target.value })}
                required
              />
            </div>

            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Décrivez le produit, ses avantages, et pourquoi c'est une bonne affaire..."
                rows={3}
                value={dealForm.description}
                onChange={(e) => setDealForm({ ...dealForm, description: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Prix actuel * (€)</Label>
              <div className="relative">
                <Euro className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  placeholder="299.99"
                  className="pl-10"
                  value={dealForm.price}
                  onChange={(e) => setDealForm({ ...dealForm, price: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="originalPrice">Prix habituel (€)</Label>
              <div className="relative">
                <Euro className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="originalPrice"
                  type="number"
                  step="0.01"
                  placeholder="399.99"
                  className="pl-10"
                  value={dealForm.originalPrice}
                  onChange={(e) => setDealForm({ ...dealForm, originalPrice: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="store">Marchand *</Label>
              <Input
                id="store"
                placeholder="ex: Amazon, Fnac, Darty..."
                value={dealForm.store}
                onChange={(e) => setDealForm({ ...dealForm, store: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Catégorie *</Label>
              <Select value={dealForm.category} onValueChange={(value) => setDealForm({ ...dealForm, category: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir une catégorie" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dealUrl">Lien vers l'offre *</Label>
              <div className="relative">
                <ExternalLink className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="dealUrl"
                  type="url"
                  placeholder="https://..."
                  className="pl-10"
                  value={dealForm.dealUrl}
                  onChange={(e) => setDealForm({ ...dealForm, dealUrl: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="expiryDate">Date d'expiration</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="expiryDate"
                  type="date"
                  className="pl-10"
                  value={dealForm.expiryDate}
                  onChange={(e) => setDealForm({ ...dealForm, expiryDate: e.target.value })}
                />
              </div>
            </div>

            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="imageUrl">URL de l'image du produit</Label>
              <div className="relative">
                <ImageIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="imageUrl"
                  type="url"
                  placeholder="https://... (optionnel)"
                  className="pl-10"
                  value={dealForm.imageUrl}
                  onChange={(e) => setDealForm({ ...dealForm, imageUrl: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t">
            <p className="text-sm text-gray-500">
              * Champs obligatoires
            </p>
            <div className="flex gap-3">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Annuler
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting || !dealForm.title || !dealForm.price || !dealForm.store || !dealForm.category || !dealForm.dealUrl}
                className="bg-green-600 hover:bg-green-700"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Publication...
                  </>
                ) : (
                  <>
                    <Tag className="mr-2 h-4 w-4" />
                    Publier le deal
                  </>
                )}
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
