import React from "react"
import { ThumbsUp, ThumbsDown, MessageCircle, ExternalLink, Flame, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DealTimer } from "@/components/DealTimer"

interface DealCardProps {
  id: string
  title: string
  description: string
  price: string
  originalPrice?: string
  discount?: string
  temperature: number
  comments: number
  image: string
  store: string
  storeLogo?: string
  author: string
  authorAvatar?: string
  timeAgo: string
  isHot?: boolean
  category?: string
  expiryDate?: string
  dealUrl?: string
}

export function DealCard({
  title,
  description,
  price,
  originalPrice,
  discount,
  temperature,
  comments,
  image,
  store,
  storeLogo,
  author,
  authorAvatar,
  timeAgo,
  isHot = false,
  category,
  expiryDate,
  dealUrl
}: DealCardProps) {
  const temperatureColor = temperature >= 100 ? "text-red-500" : temperature >= 50 ? "text-orange-500" : "text-gray-500"
  const temperatureIcon = temperature >= 100 ? Flame : temperature >= 50 ? Zap : undefined

  return (
    <Card className="hover:shadow-lg transition-shadow duration-200 border border-gray-200">
      <CardContent className="p-0">
        <div className="flex">
          {/* Temperature Voting */}
          <div className="flex flex-col items-center justify-center w-20 bg-gray-50 p-4 border-r">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-green-100">
              <ThumbsUp className="w-4 h-4 text-green-600" />
            </Button>
            <div className={`flex items-center justify-center my-2 ${temperatureColor}`}>
              {temperatureIcon && React.createElement(temperatureIcon, { className: "w-4 h-4 mr-1" })}
              <span className="font-bold text-lg">{temperature}°</span>
            </div>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-red-100">
              <ThumbsDown className="w-4 h-4 text-red-600" />
            </Button>
          </div>

          {/* Deal Image */}
          <div className="w-32 h-32 flex-shrink-0">
            <img
              src={image}
              alt={title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Deal Content */}
          <div className="flex-1 p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                {/* Category, Hot Badge, and Timer */}
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  {category && (
                    <Badge variant="secondary" className="text-xs">
                      {category}
                    </Badge>
                  )}
                  {isHot && (
                    <Badge className="bg-red-500 hover:bg-red-600 text-xs">
                      <Flame className="w-3 h-3 mr-1" />
                      HOT
                    </Badge>
                  )}
                  <DealTimer expiryDate={expiryDate} />
                </div>

                {/* Title */}
                <h3 className="font-semibold text-lg mb-2 line-clamp-2 hover:text-blue-600 cursor-pointer">
                  {title}
                </h3>

                {/* Price Information */}
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-2xl font-bold text-green-600">{price}</span>
                  {originalPrice && (
                    <>
                      <span className="text-lg text-gray-500 line-through">{originalPrice}</span>
                      {discount && (
                        <Badge variant="destructive" className="bg-red-500">
                          {discount}
                        </Badge>
                      )}
                    </>
                  )}
                </div>

                {/* Description */}
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                  {description}
                </p>

                {/* Store and Author Info */}
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center gap-2">
                    {storeLogo && (
                      <img src={storeLogo} alt={store} className="w-6 h-6 rounded" />
                    )}
                    <span className="font-medium">{store}</span>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Avatar className="w-5 h-5">
                        <AvatarImage src={authorAvatar} />
                        <AvatarFallback className="text-xs">{author[0]}</AvatarFallback>
                      </Avatar>
                      <span>{author}</span>
                    </div>
                    <span>il y a {timeAgo}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col justify-between p-4 w-40">
            <Button className="bg-green-600 hover:bg-green-700 text-white mb-2">
              <ExternalLink className="w-4 h-4 mr-2" />
              Voir le deal
            </Button>

            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              <span>{comments}</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
