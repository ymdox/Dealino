"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/contexts/AuthContext"
import {
  ThumbsUp,
  ThumbsDown,
  MessageCircle,
  ExternalLink,
  Flame,
  Share2,
  Bookmark,
  Clock,
  Store,
  Eye,
  Send
} from "lucide-react"

interface Comment {
  id: string
  author: string
  authorAvatar?: string
  content: string
  timeAgo: string
  votes: number
}

import type { Deal } from "@/types/deal"

interface DealDetailProps {
  deal: Deal
  onClose: () => void
}

export function DealDetailPage({ deal, onClose }: DealDetailProps) {
  const { user } = useAuth()
  const [newComment, setNewComment] = useState("")
  const [comments, setComments] = useState<Comment[]>([
    {
      id: "1",
      author: "BargainMaster",
      authorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
      content: "Excellent deal ! Je l'ai acheté la semaine dernière à ce prix, très content de mon achat.",
      timeAgo: "il y a 2h",
      votes: 12
    },
    {
      id: "2",
      author: "TechExpert",
      authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      content: "Attention, ce prix est uniquement pour la couleur bleue. Les autres couleurs sont plus chères.",
      timeAgo: "il y a 1h",
      votes: 8
    },
    {
      id: "3",
      author: "SaverQueen",
      authorAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b5b0?w=100&h=100&fit=crop&crop=face",
      content: "Merci pour le partage ! Commandé à l'instant 🔥",
      timeAgo: "il y a 30min",
      votes: 5
    }
  ])

  const handleAddComment = () => {
    if (!newComment.trim() || !user) return

    const comment: Comment = {
      id: Math.random().toString(36).substr(2, 9),
      author: user.username,
      authorAvatar: user.avatar,
      content: newComment,
      timeAgo: "maintenant",
      votes: 0
    }

    setComments([...comments, comment])
    setNewComment("")
  }

  const temperatureColor = deal.temperature >= 100 ? "text-red-500" : deal.temperature >= 50 ? "text-orange-500" : "text-gray-500"
  const daysRemaining = deal.expiryDate ? Math.ceil((new Date(deal.expiryDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) : null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={onClose}>
              ← Retour aux deals
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Partager
              </Button>
              <Button variant="outline" size="sm">
                <Bookmark className="w-4 h-4 mr-2" />
                Sauvegarder
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Deal Header */}
            <Card>
              <CardContent className="p-6">
                <div className="flex gap-6">
                  {/* Temperature */}
                  <div className="flex flex-col items-center">
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-green-100">
                      <ThumbsUp className="w-4 h-4 text-green-600" />
                    </Button>
                    <div className={`flex items-center justify-center my-2 ${temperatureColor}`}>
                      {deal.temperature >= 100 && <Flame className="w-4 h-4 mr-1" />}
                      <span className="font-bold text-2xl">{deal.temperature}°</span>
                    </div>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-red-100">
                      <ThumbsDown className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>

                  {/* Deal Image */}
                  <div className="w-48 h-48 flex-shrink-0">
                    <img
                      src={deal.image}
                      alt={deal.title}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  </div>

                  {/* Deal Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-3">
                      {deal.category && (
                        <Badge variant="secondary">{deal.category}</Badge>
                      )}
                      {deal.isHot && (
                        <Badge className="bg-red-500 hover:bg-red-600">
                          <Flame className="w-3 h-3 mr-1" />
                          HOT
                        </Badge>
                      )}
                      {daysRemaining && daysRemaining > 0 && (
                        <Badge variant="outline" className="text-orange-600">
                          <Clock className="w-3 h-3 mr-1" />
                          {daysRemaining} jour{daysRemaining > 1 ? 's' : ''} restant{daysRemaining > 1 ? 's' : ''}
                        </Badge>
                      )}
                    </div>

                    <h1 className="text-2xl font-bold mb-4">{deal.title}</h1>

                    {/* Price */}
                    <div className="flex items-center gap-4 mb-4">
                      <span className="text-3xl font-bold text-green-600">{deal.price}</span>
                      {deal.originalPrice && (
                        <>
                          <span className="text-xl text-gray-500 line-through">{deal.originalPrice}</span>
                          {deal.discount && (
                            <Badge variant="destructive" className="bg-red-500 text-lg px-3 py-1">
                              {deal.discount}
                            </Badge>
                          )}
                        </>
                      )}
                    </div>

                    {/* Store */}
                    <div className="flex items-center gap-2 mb-4">
                      <Store className="w-4 h-4 text-gray-500" />
                      <span className="font-medium">{deal.store}</span>
                    </div>

                    {/* Description */}
                    {deal.description && (
                      <p className="text-gray-700 mb-6">{deal.description}</p>
                    )}

                    {/* Action Button */}
                    <Button size="lg" className="bg-green-600 hover:bg-green-700">
                      <ExternalLink className="w-5 h-5 mr-2" />
                      Voir le deal
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Comments Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Commentaires ({comments.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Add Comment */}
                {user ? (
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback>{user.username[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <Textarea
                          placeholder="Ajoutez un commentaire..."
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          rows={3}
                        />
                        <div className="flex justify-end mt-2">
                          <Button
                            onClick={handleAddComment}
                            disabled={!newComment.trim()}
                            size="sm"
                          >
                            <Send className="w-4 h-4 mr-2" />
                            Commenter
                          </Button>
                        </div>
                      </div>
                    </div>
                    <Separator />
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-gray-500 mb-3">Connectez-vous pour commenter</p>
                    <Button variant="outline">Se connecter</Button>
                  </div>
                )}

                {/* Comments List */}
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex items-start gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={comment.authorAvatar} />
                        <AvatarFallback>{comment.author[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{comment.author}</span>
                          <span className="text-xs text-gray-500">{comment.timeAgo}</span>
                        </div>
                        <p className="text-gray-700 text-sm mb-2">{comment.content}</p>
                        <div className="flex items-center gap-3">
                          <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                            <ThumbsUp className="w-3 h-3 mr-1" />
                            {comment.votes}
                          </Button>
                          <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                            <ThumbsDown className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                            Répondre
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Deal Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Statistiques</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Vues
                  </span>
                  <span className="font-bold">1,247</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 flex items-center gap-2">
                    <MessageCircle className="w-4 h-4" />
                    Commentaires
                  </span>
                  <span className="font-bold">{comments.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Publié par</span>
                  <div className="flex items-center gap-2">
                    <Avatar className="w-5 h-5">
                      <AvatarImage src={deal.authorAvatar} />
                      <AvatarFallback>{deal.author[0]}</AvatarFallback>
                    </Avatar>
                    <span className="font-medium text-sm">{deal.author}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Publié</span>
                  <span className="font-bold text-sm">{deal.timeAgo}</span>
                </div>
              </CardContent>
            </Card>

            {/* Similar Deals */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Deals similaires</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center text-gray-500 py-4">
                  <p className="text-sm">Aucun deal similaire trouvé</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
