"use client"

import { useState } from "react"
import { Search, User, Plus, LogOut, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/AuthContext"
import { AuthDialog } from "@/components/AuthDialog"
import { DealSubmissionDialog } from "@/components/DealSubmissionDialog"

interface HeaderProps {
  onDealSubmitted?: (deal: any) => void
}

export function Header({ onDealSubmitted }: HeaderProps) {
  const { user, logout } = useAuth()
  const [showAuthDialog, setShowAuthDialog] = useState(false)
  const [showDealDialog, setShowDealDialog] = useState(false)

  const handleDealSubmit = () => {
    if (user) {
      setShowDealDialog(true)
    } else {
      setShowAuthDialog(true)
    }
  }
  return (
    <header className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg">
      {/* Top Navigation Bar */}
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-lg flex items-center justify-center shadow-md">
                <span className="text-white font-bold text-lg">D</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">Dealino</span>
            </div>

            {/* Navigation Links */}
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="hover:text-purple-200 transition-colors font-medium text-white/90 hover:text-white">
                Accueil
              </a>
              <a href="/deals" className="hover:text-purple-200 transition-colors font-medium text-white/90 hover:text-white">
                Bons plans
              </a>
              <a href="/discussions" className="hover:text-purple-200 transition-colors font-medium text-white/90 hover:text-white">
                Discussions
              </a>
            </nav>
          </div>

          {/* Search and Auth */}
          <div className="flex items-center space-x-4">
            {/* Search Bar */}
            <div className="hidden md:flex relative">
              <Input
                type="search"
                placeholder="Rechercher..."
                className="w-80 pl-4 pr-10 h-10 bg-white text-gray-900 border-0"
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            </div>

            {/* Auth Buttons */}
            {user ? (
              <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2 text-white">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback>{user.username[0]}</AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{user.username}</span>
                </div>

                <Button onClick={handleDealSubmit} size="sm" className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white border-0 shadow-md">
                  <Plus className="w-4 h-4 mr-2" />
                  Publier
                </Button>

                <Button variant="outline" size="sm" onClick={logout} className="hidden sm:flex bg-transparent border-white/30 text-white hover:bg-white hover:text-indigo-600">
                  <LogOut className="w-4 h-4 mr-2" />
                  Déconnexion
                </Button>
              </div>
            ) : (
              <>
                <Button variant="outline" size="sm" onClick={() => setShowAuthDialog(true)} className="hidden sm:flex bg-transparent border-white/30 text-white hover:bg-white hover:text-indigo-600">
                  <User className="w-4 h-4 mr-2" />
                  Se connecter
                </Button>

                <Button onClick={handleDealSubmit} size="sm" className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white border-0 shadow-md">
                  <Plus className="w-4 h-4 mr-2" />
                  Publier
                </Button>
              </>
            )}

            {/* Mobile Search Icon */}
            <Button variant="ghost" size="sm" className="md:hidden text-white hover:bg-white/20">
              <Search className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Auth Dialog */}
      <AuthDialog open={showAuthDialog} onOpenChange={setShowAuthDialog} />

      {/* Deal Submission Dialog */}
      <DealSubmissionDialog
        open={showDealDialog}
        onOpenChange={setShowDealDialog}
        onDealSubmitted={onDealSubmitted}
      />
    </header>
  )
}
