"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Clock, AlertTriangle } from "lucide-react"

interface DealTimerProps {
  expiryDate?: string
  className?: string
}

export function DealTimer({ expiryDate, className = "" }: DealTimerProps) {
  const [timeLeft, setTimeLeft] = useState<{
    days: number
    hours: number
    minutes: number
    seconds: number
    total: number
  } | null>(null)

  useEffect(() => {
    if (!expiryDate) return

    const calculateTimeLeft = () => {
      const difference = new Date(expiryDate).getTime() - new Date().getTime()

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
          total: difference
        })
      } else {
        setTimeLeft(null)
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [expiryDate])

  if (!expiryDate || !timeLeft) {
    return null
  }

  const isUrgent = timeLeft.total < 24 * 60 * 60 * 1000 // Less than 24 hours
  const isVeryUrgent = timeLeft.total < 6 * 60 * 60 * 1000 // Less than 6 hours

  const formatTime = () => {
    if (timeLeft.days > 0) {
      return `${timeLeft.days}j ${timeLeft.hours}h`
    } else if (timeLeft.hours > 0) {
      return `${timeLeft.hours}h ${timeLeft.minutes}m`
    } else if (timeLeft.minutes > 0) {
      return `${timeLeft.minutes}m ${timeLeft.seconds}s`
    } else {
      return `${timeLeft.seconds}s`
    }
  }

  const getVariant = () => {
    if (isVeryUrgent) return "destructive"
    if (isUrgent) return "secondary"
    return "outline"
  }

  const getIcon = () => {
    if (isVeryUrgent) return <AlertTriangle className="w-3 h-3 mr-1 animate-pulse" />
    return <Clock className="w-3 h-3 mr-1" />
  }

  const getBadgeClass = () => {
    if (isVeryUrgent) return "bg-red-500 text-white animate-pulse"
    if (isUrgent) return "bg-orange-500 text-white"
    return "bg-blue-500 text-white"
  }

  return (
    <Badge variant={getVariant()} className={`${getBadgeClass()} ${className}`}>
      {getIcon()}
      {formatTime()} restant{timeLeft.days === 1 && timeLeft.hours === 0 ? '' : 's'}
    </Badge>
  )
}

// Component for displaying multiple deal timers in a notification style
export function DealNotifications() {
  const [notifications, setNotifications] = useState([
    {
      id: "1",
      title: "iPhone 15 Pro expire bientôt !",
      expiryDate: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours
      dealId: "deal-1"
    },
    {
      id: "2",
      title: "MacBook Air - Dernières heures",
      expiryDate: new Date(Date.now() + 30 * 60 * 1000).toISOString(), // 30 minutes
      dealId: "deal-2"
    }
  ])

  const activeNotifications = notifications.filter(notification => {
    const timeLeft = new Date(notification.expiryDate).getTime() - new Date().getTime()
    return timeLeft > 0 && timeLeft < 6 * 60 * 60 * 1000 // Less than 6 hours
  })

  if (activeNotifications.length === 0) {
    return null
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2">
      {activeNotifications.map((notification) => (
        <div
          key={notification.id}
          className="bg-white border border-orange-200 rounded-lg shadow-lg p-4 max-w-sm animate-in slide-in-from-right"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm text-gray-900">{notification.title}</p>
              <DealTimer expiryDate={notification.expiryDate} className="mt-1" />
            </div>
            <button
              onClick={() => setNotifications(prev => prev.filter(n => n.id !== notification.id))}
              className="text-gray-400 hover:text-gray-600"
            >
              ×
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
