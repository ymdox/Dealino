"use client"

import { useState } from "react"
import { Header } from "@/components/Header"
import { DealCard } from "@/components/DealCard"
import { DealDetailPage } from "@/components/DealDetailPage"
import { DealTimer, DealNotifications } from "@/components/DealTimer"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AuthProvider } from "@/contexts/AuthContext"
import { Filter, TrendingUp } from "lucide-react"
import type { Deal } from "@/types/deal"

// Sample deals data with expiry dates
const initialDeals: Deal[] = [
  {
    id: "1",
    title: "Dell XPS 13 2024 Laptop, Intel Core i7, 16GB RAM, 512GB SSD, 13.3\" 4K Display",
    description: "Excellent deal on the latest Dell XPS 13 with premium specifications. Perfect for professionals and students.",
    price: "1,299 €",
    originalPrice: "1,699 €",
    discount: "-24%",
    temperature: 156,
    comments: 47,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300&h=300&fit=crop",
    store: "Dell",
    author: "TechDealer",
    timeAgo: "2h",
    isHot: true,
    category: "Informatique",
    expiryDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: "2",
    title: "Sony WH-1000XM5 Wireless Noise Canceling Headphones",
    description: "Premium noise-canceling headphones with industry-leading sound quality and 30-hour battery life.",
    price: "299 €",
    originalPrice: "399 €",
    discount: "-25%",
    temperature: 89,
    comments: 23,
    image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=300&h=300&fit=crop",
    store: "Amazon",
    author: "AudioFan",
    timeAgo: "4h",
    category: "Audio",
    expiryDate: new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString(), // 5 hours (urgent)
    authorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: "3",
    title: "Nintendo Switch OLED Console with Mario Kart 8 Deluxe Bundle",
    description: "Get the latest Nintendo Switch OLED model bundled with the popular Mario Kart 8 Deluxe game.",
    price: "329 €",
    originalPrice: "379 €",
    discount: "-13%",
    temperature: 234,
    comments: 67,
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=300&fit=crop",
    store: "Fnac",
    author: "GameMaster",
    timeAgo: "1h",
    isHot: true,
    category: "Gaming",
    expiryDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days
    authorAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: "4",
    title: "iPhone 15 Pro 256GB - Titanium Blue",
    description: "Latest iPhone 15 Pro with titanium design, advanced camera system, and USB-C connectivity.",
    price: "1,099 €",
    originalPrice: "1,229 €",
    discount: "-11%",
    temperature: 45,
    comments: 134,
    image: "https://images.unsplash.com/photo-1592286162746-43d4a01eea36?w=300&h=300&fit=crop",
    store: "Apple Store",
    author: "iPhoneFan",
    timeAgo: "6h",
    category: "Smartphones",
    expiryDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day
    authorAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b5b0?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: "5",
    title: "Samsung 55\" 4K QLED Smart TV - Neo QLED QN90C",
    description: "Immersive 55-inch 4K Neo QLED display with Quantum HDR and advanced gaming features.",
    price: "899 €",
    originalPrice: "1,299 €",
    discount: "-31%",
    temperature: 178,
    comments: 89,
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop",
    store: "Samsung",
    author: "TechSaver",
    timeAgo: "3h",
    isHot: true,
    category: "TV & Audio",
    expiryDate: new Date(Date.now() + 30 * 60 * 1000).toISOString(), // 30 minutes (very urgent)
    authorAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face"
  }
]

const featuredDeals = [
  {
    id: "featured-1",
    title: "MacBook Air M2 13\"",
    price: "999 €",
    discount: "-20%",
    store: "Apple"
  },
  {
    id: "featured-2",
    title: "AirPods Pro 2",
    price: "229 €",
    discount: "-15%",
    store: "Apple"
  },
  {
    id: "featured-3",
    title: "Tesla Model Y",
    price: "52,990 €",
    discount: "-8%",
    store: "Tesla"
  }
]

function HomePage() {
  const [deals, setDeals] = useState(initialDeals)
  const [selectedDeal, setSelectedDeal] = useState<Deal | null>(null)

  const handleDealSubmitted = (newDeal: Deal) => {
    setDeals([newDeal, ...deals])
  }

  const handleDealClick = (deal: Deal) => {
    setSelectedDeal(deal)
  }

  if (selectedDeal) {
    return (
      <AuthProvider>
        <DealDetailPage
          deal={selectedDeal}
          onClose={() => setSelectedDeal(null)}
        />
      </AuthProvider>
    )
  }

  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <Header onDealSubmitted={handleDealSubmitted} />

      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-indigo-700 via-purple-700 to-pink-600 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">
            Découvrez les meilleurs deals, bons plans et promotions
          </h1>
          <p className="text-xl opacity-90">
            Une communauté de chasseurs de bonnes affaires partage les meilleures offres chaque jour
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Main Content */}
          <main className="flex-1">
            {/* Filter Tabs */}
            <Tabs defaultValue="highlights" className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <TabsList className="bg-white border shadow-sm">
                  <TabsTrigger value="highlights" className="font-medium">
                    À la une
                  </TabsTrigger>
                  <TabsTrigger value="hot" className="font-medium">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Hot
                  </TabsTrigger>
                  <TabsTrigger value="recent" className="font-medium">
                    Récents
                  </TabsTrigger>
                  <TabsTrigger value="discussed" className="font-medium">
                    Commentés
                  </TabsTrigger>
                </TabsList>

                <Button variant="outline" className="flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  Filtres
                </Button>
              </div>

              <TabsContent value="highlights" className="space-y-4">
                {deals.map((deal) => (
                  <div key={deal.id} onClick={() => handleDealClick(deal)} className="cursor-pointer">
                    <DealCard {...deal} />
                    <DealTimer expiryDate={deal.expiryDate} className="mt-2 ml-24" />
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="hot" className="space-y-4">
                {deals.filter(deal => deal.temperature >= 100).map((deal) => (
                  <div key={deal.id} onClick={() => handleDealClick(deal)} className="cursor-pointer">
                    <DealCard {...deal} />
                    <DealTimer expiryDate={deal.expiryDate} className="mt-2 ml-24" />
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="recent" className="space-y-4">
                {deals.slice().reverse().map((deal) => (
                  <div key={deal.id} onClick={() => handleDealClick(deal)} className="cursor-pointer">
                    <DealCard {...deal} />
                    <DealTimer expiryDate={deal.expiryDate} className="mt-2 ml-24" />
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="discussed" className="space-y-4">
                {deals.slice().sort((a, b) => b.comments - a.comments).map((deal) => (
                  <div key={deal.id} onClick={() => handleDealClick(deal)} className="cursor-pointer">
                    <DealCard {...deal} />
                    <DealTimer expiryDate={deal.expiryDate} className="mt-2 ml-24" />
                  </div>
                ))}
              </TabsContent>
            </Tabs>
          </main>

          {/* Sidebar */}
          <aside className="w-80">
            <div className="space-y-6">
              {/* Featured Deals */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Deals populaires</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {featuredDeals.map((deal) => (
                    <div key={deal.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-sm">{deal.title}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-green-600 font-bold">{deal.price}</span>
                          <Badge variant="destructive" className="text-xs">
                            {deal.discount}
                          </Badge>
                        </div>
                        <span className="text-xs text-gray-500">{deal.store}</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Categories */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Catégories populaires</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {["Informatique", "Smartphones", "Gaming", "Mode", "Maison", "Auto", "Voyage", "Sport"].map((category) => (
                      <Badge key={category} variant="outline" className="cursor-pointer hover:bg-blue-50">
                        {category}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Community Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Communauté</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Membres actifs</span>
                      <span className="font-bold">47,892</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Deals partagés</span>
                      <span className="font-bold">124,567</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Économies réalisées</span>
                      <span className="font-bold text-green-600">€2.8M</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </aside>
        </div>
      </div>

      {/* Deal Notifications */}
      <DealNotifications />
    </div>
  </AuthProvider>
  )
}

export default function Home() {
  return <HomePage />
}
