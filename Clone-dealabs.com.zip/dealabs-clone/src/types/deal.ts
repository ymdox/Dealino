export interface Deal {
  id: string
  title: string
  description: string
  price: string
  originalPrice?: string
  discount?: string
  temperature: number
  comments: number
  image: string
  store: string
  storeLogo?: string
  author: string
  authorAvatar?: string
  timeAgo: string
  isHot?: boolean
  category?: string
  expiryDate?: string
  dealUrl?: string
}
